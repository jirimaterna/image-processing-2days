#!/bin/bash

#******************************
#********sronly4x**************
#******************************

SOURCE_PATH=test/target/
TARGET_PATH=test/source/
for F in `ls $SOURCE_PATH`
do 
    convert $SOURCE_PATH/$F -resize 128x128\>  $TARGET_PATH/$F
done  


SOURCE_PATH=train/target/
TARGET_PATH=train/source/
for F in `ls $SOURCE_PATH`
do 
    convert $SOURCE_PATH/$F -resize 128x128\>  $TARGET_PATH/$F
done  
